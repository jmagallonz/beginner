#  Create a Hangman game using a common words dictionary in csv from which we have excluded less than 3 characters words
#  Difficulty level could be easily adjusted by asking the user and linking the answer to a number of max_attempts
#  Creating a bilingual Spanish/English version would also be easy asking the user and using 2 dictionaries
#  Ideally, it will show some graphic of the hangman depending on how many attempts are left

import random
import csv  # Import csv to manage csv dictionary file

dictionary = []  # Create a list of words from the csv dictionary we import
with open('dictionary.csv', ) as file:
    reader = csv.reader(file)
    for row in reader:
        dictionary.append(row[0])

max_attempts = 6  # Maximum number of letters the user can request
attempts = 0  # Number of letters/resolve attempts user by the player

#  Graphics for hangman progress below
hangmanpics = ['''HANGMAN GAME! \nFIND THE SECRET WORD BEFORE YOU HANG DRY!''',
'''
  +---+
  |   |
  |    
  |       Here we go!
  |   
  |    
=========''', '''
  +---+
  |   |
  |   O 
  |    
  |   
  |    
=========''', '''
  +---+
  |   |
  |   O 
  |   | 
  |   
  |    
=========''', '''
  +---+
  |   |
  |   O 
  |  /| 
  |   
  |    
=========''', '''
  +---+
  |   |
  |   O 
  |  /|\ 
  |   
  |    
=========''', '''
  +---+
  |   |
  |   O 
  |  /|\ 
  |  / 
  |    
=========''', '''
  +---+
  |   |
  |   O 
  |  /|\    You lose!
  |  / \ 
  |    
=========''']

print(hangmanpics[0])
print(hangmanpics[1])

word = random.choice(dictionary)  # Randomly chose the word to be guessed from the dictionary list
# print(word)  # Uncomment to see the word to be guessed

word_hidden = "*" * len(word)
word_user = ""  # User entered word to check if she knows the dictionary word to win the game
print("The hidden word has", len(word), "letters")
print("Your hidden word is:", word_hidden)


def split(string):  # Function to transform strings into lists
    return list(string)


word_hidden = split(word_hidden)  # Transform word_hidden into list of characters

user_letters = []  # Empty list of letters to be entered by user

new_letter = []

user_letters = split(user_letters)  # Transform user_letters in list


def charposition(string, char):  # Function to find the character position of user_letters in word
    pos = []  # list to store positions for each 'char' in 'string'
    for n in range(len(string)):
        if string[n] == char:
            pos.append(n)
    return pos


def check_letters():  # This function checks if user_letters are in word
    counter = 0
    for letter in user_letters:  # This loop goes through user_letters and swaps them into word_hidden
        if len(charposition(word, user_letters[counter])) == 0:
            counter = counter + 1
        else:
            position = 0
            while position < len(charposition(word, user_letters[counter])):
                word_hidden[charposition(word, user_letters[counter])[position]] = user_letters[counter]
                position = position + 1
            # print(word_hidden)
            counter = counter + 1


# I need a "play" function that does the below recursively to be able to play


def game():
    attempts = 0
    while attempts <= max_attempts:
        while True:  # Make sure that user enters just 1 letter
            resolve = input("Would you like to resolve? ")  # Ask the user if she wants to guess the hidden word
            resolve = resolve.lower()
            if resolve == "yes" or resolve == "y":
                word_user = input("What's the hidden word?: ")
                word_user = word_user.lower()
                print(word_user)
                if word_user == word:
                    print("Yes,", word, "was the hidden word!", "\n""You win!")
                    exit()
                else:
                    print(word_user, "is not the hidden word!")
                    attempts += 1
                    print("You have", max_attempts - attempts, "attempts left and a last guess!")
                    print(hangmanpics[attempts])
            else:
                new_letter = input("Request a letter: ")  # List of letters entered by user to guess the word
                if new_letter.isalpha() and len(new_letter) < 2:
                    new_letter = new_letter.lower()  # Make user_letters lowercase
                    if new_letter in word:
                        print("Yes,", new_letter, "is in the hidden word!")
                    else:
                        print("Ups!", new_letter, "is not in the hidden word")
                        attempts += 1
                    new_letter.split()
                    user_letters.append(new_letter)

                    break
                print("Please enter a letter")
        print(hangmanpics[attempts])
        if (max_attempts - attempts) == 0:
            print("This is your last chance, make it count!")
        if (max_attempts - attempts) > 0:
            print("You have", max_attempts - attempts, "attempts left and a last guess!")
        check_letters()
        print("".join(word_hidden))  # Transform the list of letters into a string
    else:
        print("Ohhh!,", word, "was the hidden word!", "\n""You lose!")


game()

exit()
